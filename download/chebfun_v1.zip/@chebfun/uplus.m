function F = uplus(f)
% +	Unary plus
% +F for chebfuns is F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=f;
