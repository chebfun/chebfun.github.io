function plot(f,varargin)
% PLOT	Linear chebfun plot
% PLOT(F,G) plots chebfun G versus chebfun F.
%
% PLOT(F) plots the chebfun F.
%
% PLOT(F,'.-') plots the chebfun F and shows the function values at
% the Chebyshev points.
%
% PLOT also supports the usual string argument that controls the way the
% graph is displayed.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
n=size(f,2);
h=ishold;
c='ybgrcm';
mm='markersize';
cf='chebfun';
if (nargin>1 & isa(varargin{1},cf))
  m=2*max([f.n varargin{1}.n 1000]);
  m2=max(f.n,varargin{1}.n);
  fv=prolong(f,m2);
  gv=prolong(varargin{1},m2);
  f=prolong(f,m);
  varargin{1}=prolong(varargin{1},m);
  t=cheb(m);
else
  m=max(2000,2*f.n);
  fv=f;
  f=prolong(f,m);
  t=cheb(m);
end
if (nargin>1 & ~isa(varargin{1},cf))
  d=[findstr('.',varargin{1}) findstr('-',varargin{1})];
  d2=findstr('.',varargin{1});
elseif (nargin>2 & ~isa(varargin{2},cf))
  d=[findstr('.',varargin{2}) findstr('-',varargin{2})];
  d2=findstr('.',varargin{2});
end
if (nargin==2 & isa(varargin{1},cf))
  for i=1:n
    plot(f.fun(:,i),varargin{1}.fun(:,i),c(mod(i,6)+1))
    hold on
  end
elseif (nargin>1 & isa(varargin{1},cf) & length(d)==2)
  for i=1:n
    s=varargin{2};
    s(d)=[' ' ' '];
    if (strcmp(s,'  ')) s=c(mod(i,6)+1); end
    plot(fv.fun(:,i),gv.fun(:,i),[s '.'],mm,28,varargin{3:end})
    hold on
    plot(f.fun(:,i),varargin{1}.fun(:,i),s,varargin{3:end})
  end
elseif (nargin>1 & length(d)==2)
  for i=1:n
    s=varargin{1};
    s(d)=[' ' ' '];
    if (strcmp(s,'  ')) s=c(mod(i,6)+1); end
    plot(cheb(fv.n),fv.fun(:,i),[s '.'],mm,28,varargin{2:end})
    hold on
    plot(t,f.fun(:,i),s,varargin{2:end})
  end
elseif (nargin>1 & isa(varargin{1},cf) & length(d2)==1)
  for i=1:n
    s=varargin{2};
    s(d2)=[' '];
    if (strcmp(s,' ')) s=c(mod(i,6)+1); end
    plot(fv.fun(:,i),gv.fun(:,i),[s '.'],mm,28,varargin{3:end})
  end
elseif (nargin>1 & length(d2)==1)
  for i=1:n
    s=varargin{1};
    s(d2)=[' '];
    if (strcmp(s,' ')) s=c(mod(i,6)+1); end
    plot(cheb(fv.n),fv.fun(:,i),[s '.'],mm,28,varargin{2:end})
  end
elseif (~isreal(f.fun))
  plot(real(f),imag(f),varargin{2:end});
else
  for i=1:n
    if (nargin>1)
      plot(t,f.fun(:,i),varargin{:})
    else
      plot(t,f.fun(:,i),c(mod(i,6)+1))
    end
    hold on
  end
end
if h, hold on; else hold off; end
