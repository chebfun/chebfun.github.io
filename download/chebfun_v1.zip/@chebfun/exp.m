function F = exp(f);
% EXP	Exponential
% EXP(F) is the exponential of the chebfun F, e to the F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@exp,f);
