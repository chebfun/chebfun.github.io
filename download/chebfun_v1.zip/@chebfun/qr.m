function [q,r] = qr(A,econ)
% QR	QR factorization
% [Q,R]=QR(A,0) produces a matrix Q with orthogonal column chebfuns and an upper
% triangular matrix R such that A=Q*R.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (nargin==2 & econ==0)
  [m,n]=size(A.fun);
  q=A;
  q.fun=[];
  QS=A;
  AS=A;
  AT=A;
  for j=1:n
    AS.fun=A.fun(:,j);
    r(j,j)=norm(AS);
    if (r(j,j)>=eps)
      qfun=AS.fun/r(j,j);
      q.fun(:,j)=qfun;
    else
      T=struct('type','()','subs',{{':'}});
      temp=chebfun('1',m-1);
      temp.fun=randn(m,1);
      for i=1:j-1
        T.subs{2}=i;
        temp=temp-subsref(q,T)'*temp*subsref(q,T);
      end
      temp=temp/norm(temp);
      q.fun(:,j)=temp.fun;
      r(j,j)=0;
      qfun=q.fun(:,j);
    end
    ii=j+1:n;
    QS.fun=qfun;
    Aii=A.fun(:,ii);
    AT.fun=Aii;
    if (j+1<=n), r(j,ii)=QS'*AT; end
    A.fun(:,ii)=Aii-repmat(r(j,ii),m,1).*repmat(qfun,1,length(ii));
  end
else
  error('Use qr(A,0) for economy size decomposition.');
end
