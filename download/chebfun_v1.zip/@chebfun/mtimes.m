function F = mtimes(f,g)
% *	Scalar multiplication
% F*G multiplies a chebfun by a scalar.
% If F is a row chebfun and G a column chebfun, F*G returns
% the integral from -1 to 1 of F.*G.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (isempty(f) | isempty(g)), F=chebfun; return; end
if (isa(f,'double'))
  F=g;
  F.fun=f*g.fun;
elseif (isa(g,'double'))
  if (f.trans)
    F=g*sum(f);
  else
    F=f;
    F.fun=f.fun*g;
  end
elseif (f.trans)
  n=size(f.fun,1);
  n2=size(g.fun,2);
  fg=f.n+g.n;
  f=prolong(f.',fg);
  g=prolong(g,fg);
  fn=f.fun;
  gn=g.fun;
  temp=g;
  F=zeros(n,n2);
  for i=1:n
    temp.fun=fn(:,i*ones(n2,1)).*gn;
    F(i,:)=sum(temp);
  end
elseif (g.trans)
  F=f;
  F.fun=f.fun*g.fun;
  F.td=1;
elseif (f.td)
  f=f.';
  temp=chebfun;
  temp2=g;
  [m,n]=size(f.fun);
  [m2,n2]=size(g);
  temp.n=m-1;
  for i=1:n
    temp.fun=f.fun(:,i);
    for j=1:n2
      temp2.fun=g.fun(:,j);
      temp3(i,j)=sum(temp.*temp2);
    end
  end
  F=chebfun;
  F.fun=temp3;
  F.n=n-1;
elseif(isa(f,'chebfun') & isa(g,'chebfun'))
  error('Use .* to multiply chebfuns.');
end
