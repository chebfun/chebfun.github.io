function F = asin(f)
% ASIN	Inverse sine
% ASIN(F) is the arcsine of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@asin,f);
