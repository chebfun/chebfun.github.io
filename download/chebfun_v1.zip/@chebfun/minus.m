function F = minus(f,g)
% -	Minus
% F - G subtracts chebfun G from F or a scalar from a chebfun if either
% F or G is a scalar.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (isempty(f) | isempty(g)), F=chebfun; return; end
if isa(f,'double')
  F=g;
  F.fun=f-g.fun;
  return;
elseif isa(g,'double')
  F=f;
  F.fun=f.fun-g;
  return;
end
fn=f.n;
gn=g.n;
if (fn > gn)
  F=f;
  g=prolong(g,fn);
  F.fun=f.fun-g.fun;
elseif fn < gn
  F=g;
  f=prolong(f,gn);
  F.fun=f.fun-g.fun;
elseif (f.fun==g.fun)
  F=f;
  F.fun=0;
  F.n=0;
else
  F=f;
  F.fun=f.fun-g.fun;
end
