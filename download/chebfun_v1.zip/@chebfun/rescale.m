function F = rescale(f,n)
% RESCALE	Rescale chebfun
% RESCALE(F,N) returns the order N representation of the chebfun F.
% RESCALE(F) returns the minimal representation of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (nargin==2)
  F=prolong(f,n);
else
  F=simplify(f);
end
