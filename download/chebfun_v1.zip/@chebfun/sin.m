function F = sin(f)
% SIN	Sine
% SIN(F) is the sine of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@sin,f);
