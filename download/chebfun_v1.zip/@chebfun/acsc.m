function F = acsc(f)
% ACSC	Inverse cosecant
% ACSC(F) is the inverse cosecant of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@acsc,f);
