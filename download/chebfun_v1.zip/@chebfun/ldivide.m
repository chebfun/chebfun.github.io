function out = ldivide(f,g)
% .\	Left chebfun divide
% F .\ G is the chebfun left division of F and G.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
out=rdivide(g,f);
