function F = log2(f)
% LOG2	Base 2 logarithm
% LOG2(F) is the base 2 logarithm of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@log2,f);
