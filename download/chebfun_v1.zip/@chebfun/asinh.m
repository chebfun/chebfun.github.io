function F = asinh(f)
% ASINH	Inverse hyperbolic sine
% ASINH(F) is the inverse hyperbolic sine of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@asinh,f);
