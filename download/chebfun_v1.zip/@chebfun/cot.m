function F = cot(f)
% COT	Cotangent
% COT(F) is the cotangent of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@cot,f);
