function F = eq(f,g)
% ==	Equal
% F == G compares chebfuns F and G and returns one if F and G are
% equal and zero otherwise.  A scalar can be compared with a chebfun.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (isa(f,'double'))
  f=f*chebfun('1');
elseif (isa(g,'double'))
  g=g*chebfun('1');
end
f=simplify(f);
g=simplify(g);
if (length(f.fun)==length(g.fun))
  F=min(f.fun==g.fun);
else
  F=(1==0);
end
