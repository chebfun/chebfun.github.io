function F = acos(f)
% ACOS	Inverse cosine
% ACOS(F) is the arccosine of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@acos,f);
