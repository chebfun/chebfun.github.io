function F = atan(f)
% ATAN	Inverse tangent
% ATAN(F) is the arctangent of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@atan,f);
