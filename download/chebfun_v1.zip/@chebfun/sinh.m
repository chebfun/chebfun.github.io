function F = sinh(f)
% SINH	Hyperbolic sine
% SINH(F) is the hyperbolic sine of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@sinh,f);
