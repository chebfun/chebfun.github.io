function F = sec(f)
% SEC	Secant
% SEC(F) is the secant of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@sec,f);
