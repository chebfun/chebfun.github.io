function chebfunobj = chebfun(f,n,m)
% CHEBFUN	Constructor
% CHEBFUN(F) constructs a chebfun object for the function F.  If F is a string
% such as '3*x.^2+1', CHEBFUN(F) automatically determines the number of points
% for F.  F can also be a vector such as [1 0 0] which allows the construction
% of a chebfun with Chebyshev coefficients F.
%
% CHEBFUN(F,N) where F is a string and N a nonnegative integer creates a chebfun
% for F with N+1 Chebyshev points.
%
% CHEBFUN creates an empty chebfun.
%
% For more on chebfuns, see Z. Battles and L. N. Trefethen,
% "An extension of Matlab to continuous functions and operators", 2003.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if nargin==0
  chebfunobj=struct('fun',[],'n',[],'trans',int8(0),'td',int8(0));
  chebfunobj=class(chebfunobj,'chebfun');  
elseif (isempty(f) & nargin==2)
  chebfunobj=struct('fun',n,'n',size(n,1)-1,'trans',int8(0),'td',int8(0));
  chebfunobj=class(chebfunobj,'chebfun');  
elseif (isa(f,'double'))
  c=chebpolyval(f(:));
  chebfunobj=struct('fun',c,'n',length(c)-1,'trans',int8(0),'td',int8(0));
  chebfunobj=class(chebfunobj,'chebfun');  
elseif ((~isempty(str2num(f)) & nargin==1) | (length(f)==4 & strcmp(f(2:4),'.^0')))
  chebfunobj=struct('fun',[],'n',[],'trans',int8(0),'td',int8(0));
  x=cheb(0);
  f=inline(f);
  chebfunobj.fun=0*x+f(x);
  chebfunobj.n=0;
  chebfunobj=class(chebfunobj,'chebfun');  
elseif nargin == 1
  chebfunobj=auto(inline(f),chebfun('x',1));
else
  chebfunobj=struct('fun',[],'n',[],'trans',int8(0),'td',int8(0));
  x=cheb(n);
  f=inline(f);
  chebfunobj.fun=0*x+f(x);
  chebfunobj.n=n;
  chebfunobj=class(chebfunobj,'chebfun');
end
