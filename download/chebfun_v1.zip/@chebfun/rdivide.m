function F = rdivide(f,g)
% ./	Right chebfun divide
% F./G is the chebfun division of G into F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (isempty(f) | isempty(g)), F=chebfun; return; end
if (isa(g,'double'))
  F = mrdivide(f,g);
elseif (isa(f,'double'))
  f=f*chebfun('1');
  F=auto(@rdivide,f,g);
elseif(length(f.fun)==length(g.fun) & f.fun==g.fun)
  F=f;
  F.fun=1;
  F.n=0;
else
  F=auto(@rdivide,f,g);
end
