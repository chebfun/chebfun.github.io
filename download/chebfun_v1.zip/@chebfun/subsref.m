function F = subsref(f,S)
% SUBSREF	Subscripted reference
% F(X) evaluates the chebfun F at the values given in X.  The case where X
% is a chebfun results in function composition.
%
% F(I,J), F a matrix whose columns are chebfuns, evaluates the J-th
% chebfun at the value I.  F(I,:) evaluates all chebfuns in F at I and
% F(:,J) returns the J-th chebfun of F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if strcmp(S.type,'()')
  if isa(S.subs{1},'chebfun')
    F=auto(@comp,f,S.subs{1});
  elseif f.td
    S.subs{1}=S.subs{1}(:);
    S.subs{2}=S.subs{2}(:);
    F=bary2([S.subs{1} S.subs{2}],f.fun);
  elseif ~f.trans
    if length(S.subs)==1
      F=bary(S.subs{1},f.fun);
      F=reshape(F,size(S.subs{1}));
    elseif strcmp(S.subs{1},':')
      F=f;
      F.fun=f.fun(:,S.subs{2});
    elseif strcmp(S.subs{2},':')
      n=size(f.fun,2);
      for i=1:n
        F(:,i)=bary(S.subs{1},f.fun(:,i));
      end
    else
      s=S.subs{2};
      for j=1:length(s)
        F(:,j)=bary(S.subs{1},f.fun(:,s(j)));
      end
    end
  else
    if length(S.subs)==1
      F=bary(S.subs{1},f.fun);
    elseif strcmp(S.subs{2},':')
      F=f;
      F.fun=f.fun(S.subs{1},:);
    elseif strcmp(S.subs{1},':')
      m=size(f.fun,1);
      for i=1:m
        F(:,i)=bary(S.subs{2},f.fun(i,:));
      end
    else
      s=S.subs{1};
      for i=1:length(s)
        F(i,:)=bary(S.subs{2},f.fun(s(i),:))';
      end
    end
  end
end
