function F = csc(f)
% CSC	Cosecant
% CSC(F) is the cosecant of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
F=auto(@csc,f);
