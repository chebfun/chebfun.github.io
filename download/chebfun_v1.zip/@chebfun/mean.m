function out = mean(f)
% MEAN	Average or mean value
% MEAN(F) is the mean value of the chebfun F.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
out = sum(f)/2;
