function F = sign(f)
% SIGN	Sign function
% For a chebfun, SIGN(F) returns a chebfun which is 1 if F is
% positive throughout [-1,1], -1 if F is negative throughout [-1,1]
% and empty if F has roots in [-1,1].

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (~isreal(f.fun)), F=exp(i*imag(log(f))); return; end
F=f;
r=introots(f);
if (isempty(r))
  F.fun=sign(bary(0,f.fun));
  F.n=0;
else
  F.fun=[];
  F.n=0;
end
