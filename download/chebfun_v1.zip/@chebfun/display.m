function display(X)
% DISPLAY	Display chebfun
% DISPLAY(F) is called when the semicolon is not used at the end of a statement.
% DISPLAY(F) shows the type of chebfun and the function values at the
% Chebyshev points.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if isequal(get(0,'FormatSpacing'),'compact')
  if (isempty(X))
    disp([inputname(1) ' = empty chebfun']);
  elseif (X.trans & ~X.td)
    disp([inputname(1) ' = row chebfun']);
  elseif (~X.trans & ~X.td)
    disp([inputname(1) ' = column chebfun']);
  else
    disp([inputname(1) ' = matrix chebfun']);
  end
  disp([X.fun])
else
  disp(' ')
  if (X.trans & ~X.td)
    disp([inputname(1) ' = row chebfun']);
  elseif (~X.trans & ~X.td)
    disp([inputname(1) ' = column chebfun']);
  else
    disp([inputname(1) ' = matrix chebfun']);
  end
  disp(' ');
  disp([X.fun])
end
