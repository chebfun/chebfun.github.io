function F = power(f,b)
% .^	Chebfun power
% F.^G returns a chebfun F to the scalar power G or a scalar F to the
% chebfun power G.

% Copyright 2003 Zachary Battles, Chebfun Version 1.0
if (isa(f,'chebfun') & isa(b,'chebfun'))
  error('Cannot raise a chebfun to the power of a chebfun.');
end
if (isa(f,'double'))
  F=exp(log(f)*b);
else
  F = auto(@power,f,b*chebfun('1'));
end
if (norm(imag(F.fun))<eps), F.fun=real(F.fun); end
