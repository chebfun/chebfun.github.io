function C = uminus(A)
% -   Negate oparray.

% Copyright 2008-2009 by Toby Driscoll. 
% See http://www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 886 $:
%  $Date: 2009-12-03 12:43:28 +0000 (Thu, 03 Dec 2009) $:

if isempty(A) 
  C = oparray({});
  return
end

fun = @(a) anon('@(u) -feval(a,u)',{'a'},{a});
op = cellfun( fun, A.op, 'uniform',false );
C = oparray(op);

end
