function s = char(f)
%CHAR   Convert anon to string.

% Copyright 2009 by Toby Driscoll.
% See http://www.maths.ox.ac.uk/chebfun/.

%  Last commit: $Author: driscoll $: $Rev: 885 $:
%  $Date: 2009-12-03 12:40:54 +0000 (Thu, 03 Dec 2009) $:

s = f.function;

end