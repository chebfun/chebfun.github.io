function Nout = minus(N1,N2)
% -  Difference of chebops

Nout = plus(N1,-N2);
end