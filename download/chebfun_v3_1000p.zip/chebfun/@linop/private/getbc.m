function bc = getbc(A)

% Unites the left bc and right bc into a single structure.

% Copyright 2008 by Toby Driscoll.
% See http://www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:

bc = struct('left',A.lbc,'right',A.rbc);

end