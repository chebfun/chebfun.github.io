function E = exp(A)
% EXP   Exponential of a chebop.
% EXP(A) is a synonym for EXPM(A).
%
% See also CHEBOP/EXPM.
% See http://www.maths.ox.ac.uk/chebfun.

% Copyright 2008 by Toby Driscoll.

%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:

E = expm(A);

end