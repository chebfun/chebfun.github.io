function e = isempty(A)
% ISEMPTY   True for empty linop.

% Copyright 2008 by Toby Driscoll.
% See http://www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:

e = isempty(A.varmat) && isempty(A.oparray);

end