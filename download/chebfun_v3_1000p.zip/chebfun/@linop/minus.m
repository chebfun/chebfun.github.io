function C = minus(A,B)
% -  Difference of linops.
% If A and B are linops, A-B returns the linop that represents their
% difference. If one is a scalar, it is interpreted as the scalar times the
% identity operator.
%
% See www.maths.ox.ac.uk/chebfun.

% Copyright 2008 by Toby Driscoll.
%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:


C = plus(A,-B);
end