function F = uplus(F)
% +	  Unary plus.
% +F for a chebfun is F.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

