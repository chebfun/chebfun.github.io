function cg = loaddemos(guifile,guifilepath)

% Copyright 2011 by The University of Oxford and The Chebfun Developers. 
% See http://www.maths.ox.ac.uk/chebfun/ for Chebfun information.

% Defaults
name = '';
demotype = '';
a = ''; 
b = '';
t = '';
DE = '';
LBC = ''; 
RBC = '';
init = ''; 
tol = '';
damping = '';
plotting = '';
sigma = '';
numeigs = '';

% Import from the given file and evaluate to fill the workspace
fid = fopen(guifilepath);
while 1
    tline = fgetl(fid);
    if ~ischar(tline), break, end
    eval(tline);
end
fclose(fid);

% Create the options structure
options = struct('damping',damping,'plotting',plotting,'numeigs',numeigs);

% Build the chebguifile
cg = chebgui('type',demotype,'domleft',a,'domright',b,'timedomain',t,'de',DE,...
    'lbc',LBC,'rbc',RBC,'init',init,'tol',tol,...
    'options',options);
