function [ output_args ] = display( cg)
%DISP Summary of this function goes here
%   Detailed explanation goes here

% Copyright 2011 by The University of Oxford and The Chebfun Developers. 
% See http://www.maths.ox.ac.uk/chebfun/ for Chebfun information.

struct(cg)
end

