function C = minus(A,B)
% -   Difference of oparrays.

% Copyright 2008 by Toby Driscoll. 
% See http://www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 886 $:
%  $Date: 2009-12-03 12:43:28 +0000 (Thu, 03 Dec 2009) $:

C = plus(A,-B);

end