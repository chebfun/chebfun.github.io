function f = flipud(f)
% FLIPUD Flip/reverse a fun.
%
% G = FLIPUD(F) returns a fun G such that G(x)=F(-x) for all x.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

ends = f.map.par(1:2);
if isinf(ends(1)) ||isinf(ends(2))
    error('FUN:flipud:unbounded','FLIPUD cannot be used on unbounded domanins');
end
f.vals = flipud(f.vals);
