function g1 = plus(g1,g2)
% +	Plus
% G1 + G2 adds funs G1 and G2 or a scalar to a fun if either G1 or G2 is a
% scalar.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

g1 = minus(g1,-g2);