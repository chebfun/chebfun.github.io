function F = mldivide(c,f)
% \	Left scalar divide
% C\F divides the fun F by a scalar C.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

F = mrdivide(f,c);