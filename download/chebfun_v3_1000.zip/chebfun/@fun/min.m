function [out,i] = min(g)
% MIN	Global minimum on [-1,1]
% MIN(G) is the global minimum of the fun G on [-1,1].
% [Y,X] = MIN(G) returns the value X such that Y = G(X), Y the global minimum.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

[out,i] = max(-g);
out=-out;