function dom = domain(A)
% DOMAIN   Domain of function defintion.

% Copyright 2008 by Toby Driscoll.
% See http://www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:

dom = A.fundomain;

end