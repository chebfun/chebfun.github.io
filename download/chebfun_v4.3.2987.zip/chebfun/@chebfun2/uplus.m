function f = uplus(f)
%UPLUS, unary plus for a chebfun2. 