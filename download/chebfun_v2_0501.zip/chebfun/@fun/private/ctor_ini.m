function g = ctor_ini()

% Copyright 2002-2008 by The Chebfun Team. See www.comlab.ox.ac.uk/chebfun/

g = struct([]);
g(1).vals = [];
g(1).n    = [];
g(1).scl  = struct('h',1,'v',0);