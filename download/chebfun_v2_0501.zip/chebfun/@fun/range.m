function r = range(g)
% Range of a fun, i.e. max(g) - min(g)
%
% See http://www.comlab.ox.ac.uk/chebfun for chebfun information.

%  Copyright 2002-2009 by The Chebfun Team. 
%  Last commit: $Author: nich $: $Rev: 489 $:
%  $Date: 2009-06-04 22:25:42 +0100 (Thu, 04 Jun 2009) $:

if ~isreal(g)
    r = range(abs(chebfun(g)));
    return
end

r = diff(minandmax(g));
