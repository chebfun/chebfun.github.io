function pref = chebopdefaults
% Default chebfunprefs for chebops

%  Copyright 2002-2009 by The Chebfun Team. 
%  Last commit: $Author: nich $: $Rev: 493 $:
%  $Date: 2009-06-05 15:56:23 +0100 (Fri, 05 Jun 2009) $:

pref = chebfunpref;
pref.splitting = false;
pref.sampletest = false;
pref.resampling = true;

