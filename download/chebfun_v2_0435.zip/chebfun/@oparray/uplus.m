function A = uplus(A)
% +   Same oparray.

% Copyright 2008 by Toby Driscoll. See www.comlab.ox.ac.uk/chebfun.

end
