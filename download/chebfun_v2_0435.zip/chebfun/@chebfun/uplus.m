function F = uplus(F)
% +	  Unary plus.
% +F for a chebfun is F.
%
% See http://www.comlab.ox.ac.uk/chebfun for chebfun information.

