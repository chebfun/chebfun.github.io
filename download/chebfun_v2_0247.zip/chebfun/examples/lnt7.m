% lnt7.m Find Chebyshev coeffs. of sin(x)  LNT 12.06
disp(chebpoly(chebfun('sin(x)')))
