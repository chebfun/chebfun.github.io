% lnt9.m  Interpolate random data  LNT 12/06

%subplot(2,1,1)
plot(chebfun(rand(51,1)),'.-','linewidth',1,'markersize',16)
axis([-1 1 -.2 1.2])
grid on

