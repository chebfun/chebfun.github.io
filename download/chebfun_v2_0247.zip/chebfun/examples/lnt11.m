% lnt11.m  Find coefficients of a polynomial  LNT 12.06

x = fun('x');
% command poly hasn't been implemented correctly.
poly((1+2*x).^6)