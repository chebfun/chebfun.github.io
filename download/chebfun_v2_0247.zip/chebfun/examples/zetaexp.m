% evaluate zeta(exp(z)+1)

 function zetaexp = zetaexp(z)
 zetaexp = zeta(exp(z)+1);