% lnt8.m illustrate the Gibbs phenomenon  LNT 12.06

f = chebfun('sign(x)',25);
plot(f,'.-')