function Fout = uminus(F)
% -	Unary minus
% -F negates the chebfun F.

% Chebfun Version 2.0

Fout = -1*F;