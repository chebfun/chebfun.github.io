function F = uplus(F)
% +	Unary plus
% +F for chebfuns is F.

% Chebfun Version 2.0
