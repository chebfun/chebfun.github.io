function Fout = prod(F)

Fout = exp(sum(log(F)));