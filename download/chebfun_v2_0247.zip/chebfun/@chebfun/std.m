function out = std(f)
% STD	Standard deviation
% STD(F) is the standard deviation of the chebfun F.

out = sqrt(var(f));