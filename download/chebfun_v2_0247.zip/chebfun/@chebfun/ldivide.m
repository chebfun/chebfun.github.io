function h = ldivide(f,g)
% .\	Left chebfun division
% F .\ G is the chefun left division of F and G.
h = rdivide(g,f);