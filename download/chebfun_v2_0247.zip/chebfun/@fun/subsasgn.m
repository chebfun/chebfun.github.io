function out = subsasgn(varargin)
% Fun SUBSASGN just call the built-in SUBSASGN.

out = builtin('subsasgn',varargin{:});
