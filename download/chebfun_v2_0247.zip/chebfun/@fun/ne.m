function F = ne(f,g)
% ~=	Not equal
% F ~= G compares funs F and G and returns one if F and G are
% not equal and zero otherwise. 

% Rodrigo Platte, Feb 2008.

F= ~eq(f,g);