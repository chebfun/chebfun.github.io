function g = ctor_ini()

g = struct([]);
g(1).vals = [];
g(1).n    = [];
g(1).scl  = struct('h',1,'v',0);