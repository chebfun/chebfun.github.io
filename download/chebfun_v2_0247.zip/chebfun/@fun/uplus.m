function gout = uplus(g)
% +	Unary plus
% +G for funs is G.

gout = g;