function Fout = erfcx(F)
% ERFCX  Scaled complementary error function of a chebfun.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 

Fout = comp(F, @(x) erfcx(x));
for k = 1:numel(F)
  Fout(k).jacobian = anon('@(u) diag(-2/sqrt(pi) + 2*F.*Fout)*diff(F,u)',{'F' 'Fout'},{F(k) Fout(k)});
  Fout(k).ID = newIDnum();
end