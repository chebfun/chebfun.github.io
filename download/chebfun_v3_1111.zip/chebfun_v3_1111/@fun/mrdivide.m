function F = mrdivide(f,g)
% /	Right scalar divide
% F/C divides the fun F by a scalar C.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

F=f;
if (isa(g,'double'))
    F.vals=f.vals/g;
    F.scl.v=f.scl.v/abs(g);
else
    error('FUN:mrdivide:funfun','Use ./ to divide a fun into a fun.');
end