function len = length(g)
% LENGTH	Length of a fun
% LENGTH(F) is the number of Chebyshev points N. 
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

len = g.n;
