function display(g)
% DISPLAY	Display fun
% DISPLAY(G) is called when the semicolon is not used at the end of a statement.
% DISPLAY(G) shows the type of fun and the function values at the
% Chebyshev points.
%
% See http://www.maths.ox.ac.uk/chebfun for chebfun information.

% Copyright 2002-2009 by The Chebfun Team. 
% Last commit: $Author: hale $: $Rev: 987 $:
% $Date: 2009-12-15 10:13:36 +0000 (Tue, 15 Dec 2009) $:

if isequal(get(0,'FormatSpacing'),'compact')
    if numel(g) == 1
      if (isempty(g))
        disp([inputname(1) ' = empty fun'])
      else
        disp([inputname(1) ' = column fun'])
        disp([g.vals])
      end      
    else
        disp([inputname(1) ' = vector of funs'])
        for k = 1:numel(g)
            disp(['length of fun' num2str(k) ': ' num2str(length(g(k)))]);
        end
    end 
else
    if numel(g) == 1        
        if (isempty(g))
            disp(' ')
            disp([inputname(1) ' = empty fun'])
            disp(' ')
        else
          disp(' ')
          disp([inputname(1) ' = column fun']);
          disp(' ')
          disp([g.vals])
          disp(' ')
        end
    else
        disp(' ')
        disp([inputname(1) ' = vector of funs'])
        disp(' ')
        for k = 1:numel(g)
            disp(['length of fun ' num2str(k) ': ' num2str(length(g(k)))]);
        end
        disp(' ')
    end     
end