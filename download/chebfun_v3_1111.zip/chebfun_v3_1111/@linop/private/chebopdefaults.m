function pref = chebopdefaults
% Default chebfunprefs for chebops

%  Copyright 2002-2009 by The Chebfun Team. 
%  Last commit: $Author: hale $: $Rev: 1069 $:
%  $Date: 2010-03-31 19:50:15 +0100 (Wed, 31 Mar 2010) $:

pref = chebfunpref;
pref.splitting = false;
pref.sampletest = false;
pref.resampling = true;
pref.exps = [0 0];
pref.blowup = 0;
pref.vecwarn = 0;
pref.chebkind = 2;

