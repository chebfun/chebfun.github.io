function B = copy(A)

% Copy a linop into another, preserving everything but the ID number.

% Copyright 2009 by Toby Driscoll.
% See www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:

B = A;
B.ID = newIDnum();

end
