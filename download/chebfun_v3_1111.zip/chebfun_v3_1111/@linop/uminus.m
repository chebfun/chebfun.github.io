function C = uminus(A)
% -  Negate a linop.

% Copyright 2008 by Toby Driscoll.
% See http://www.maths.ox.ac.uk/chebfun.

%  Last commit: $Author: driscoll $: $Rev: 907 $:
%  $Date: 2009-12-04 15:49:08 +0000 (Fri, 04 Dec 2009) $:

C = copy(A);
C.varmat = -C.varmat;
C.oparray = -C.oparray;

end