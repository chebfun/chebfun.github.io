function Nout = minus(N1,N2)
%-  Difference of chebops

% Copyright 2011 by The University of Oxford and The Chebfun Developers. 
% See http://www.maths.ox.ac.uk/chebfun/ for Chebfun information.

Nout = plus(N1,-N2);

end